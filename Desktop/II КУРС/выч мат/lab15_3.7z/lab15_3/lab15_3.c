#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double a=1.0;
double b=5.0;

double func(double x){
  return cosh(x)-x*x*2.0+3.0;
}

double lagrange_func(int n, double** nodes, double x){
  double res = 0;
  for(int j=0; j<n; ++j){
    double koef = 1;
    for(int i=0;i<n;++i){
      if(i!=j){
        koef *= (x-nodes[i][0])/(nodes[j][0]-nodes[i][0]);
      }
    }
    res += koef*nodes[j][1];
  }
  return res;
}

double** calc_lagrange_nodes(int nn){
  double** nodes = malloc(nn*sizeof(double*));
  for(int i=0;i<nn; ++i){
    nodes[i] = malloc(2*sizeof(double));
    nodes[i][0] = a + ((b-a)/(nn-1))*i;
    nodes[i][1] = func(nodes[i][0]);
  }
  return nodes;
}

double** calc_chebishev_nodes(int nn){
  double** nodes = malloc(nn*sizeof(double*));
  for(int i=0;i<nn; ++i){
    nodes[i] = malloc(2*sizeof(double));
    nodes[i][0] = (a+b)/2.0+((b-a)/2.0)*cos(((nn-(i+1)+0.5)/nn)*M_PI);
    nodes[i][1] = func(nodes[i][0]);
  }
  return nodes;
}

int main(){
  double** lagrange_nodes3 = calc_lagrange_nodes(3);
  double** lagrange_nodes4 = calc_lagrange_nodes(4);
  double** lagrange_nodes10 = calc_lagrange_nodes(10);
  double** lagrange_nodes16 = calc_lagrange_nodes(16);

  double** chebishev_nodes3 = calc_chebishev_nodes(3);
  double** chebishev_nodes4 = calc_chebishev_nodes(4);
  double** chebishev_nodes10 = calc_chebishev_nodes(10);
  double** chebishev_nodes16 = calc_chebishev_nodes(16);

  double d_l3 = 0;
  double d_l4 = 0;
  double d_l10 = 0;
  double d_l16 = 0;
  double d_c3 = 0;
  double d_c4 = 0;
  double d_c10 = 0;
  double d_c16 = 0;
  FILE* out = fopen("data.dat", "w");
  for(double s=a; s<=b; s+=0.01){
    double f = func(s);
    double l3 = lagrange_func(3, lagrange_nodes3, s);
    double l4 = lagrange_func(4, lagrange_nodes4, s);
    double l10 = lagrange_func(10, lagrange_nodes10, s);
    double l16 = lagrange_func(16, lagrange_nodes16, s);
    double c3 = lagrange_func(3, chebishev_nodes3, s);
    double c4 = lagrange_func(4, chebishev_nodes4, s);
    double c10 = lagrange_func(10, chebishev_nodes10, s);
    double c16 = lagrange_func(16, chebishev_nodes16, s);
    if(fabs(f - l3) > d_l3){
      d_l3 = fabs(f - l3);
    }
    if(fabs(f - l4) > d_l4){
      d_l4 = fabs(f - l4);
    }
    if(fabs(f - l10) > d_l10){
      d_l10 = fabs(f - l10);
    }
    if(fabs(f - l16) > d_l16){
      d_l16 = fabs(f - l16);
    }

    if(fabs(f - c3) > d_c3){
      d_c3 = fabs(f - c3);
    }
    if(fabs(f - c4) > d_c4){
      d_c4 = fabs(f - c4);
    }
    if(fabs(f - c10) > d_c10){
      d_c10 = fabs(f - c10);
    }
    if(fabs(f - c16) > d_c16){
      d_c16 = fabs(f - c16);
    }

    fprintf(out, "%e %e %e %e %e %e %e %e %e %e  %e %e %e %e %e %e %e %e %e\n", s, f, l3, l4, l10, l16, f-l3, f-l4, f-l10, f-l16, c3, c4, c10, c16, f-c3, f-c4, f-c10, f-c16);
  }
  fclose(out);
  printf("n\t\tequidistant\t\tchebishev\n");
  printf("3\t\t%e\t\t%e\n", d_l3, d_c3);
  printf("4\t\t%e\t\t%e\n", d_l4, d_c4);
  printf("10\t\t%e\t\t%e\n", d_l10, d_c10);
  printf("16\t\t%e\t\t%e\n", d_l16, d_c16);

  return 0;
}
