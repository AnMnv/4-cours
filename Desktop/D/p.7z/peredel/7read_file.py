#!/usr/bin/env python
#coding=utf8
import json;
import matplotlib.pyplot as plt

with open('data.txt') as json_file:
    data = json.load(json_file)
    plt.plot(data['x'], data['y'], data['A'], data['color'])
    plt.xlabel('Time, s')
    plt.ylabel('Amplitude')
    plt.title('Square wave(readen from file)')
    plt.grid(True)
    axes = plt.gca()
    axes.set_xlim([-1,11])
    axes.set_ylim([-1,data['A']+1])
    plt.show()