#!/usr/bin/env python
#coding=utf8
import numpy as np
import matplotlib.pyplot as plt

x = np.arange(1, 10, 0.05)
y = 5*x + 3
plt.title("Linear dependence y = 5x+3")
plt.xlabel('x')
plt.ylabel('y')
plt.plot(x, y, "r")
plt.show()
